//
//  alarmList.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/09.
//

import Foundation


class AlarmGroup:NSObject{
    var alarms = [Alarm]()
    override init() {
        super.init()
    }
    func count()->Int{
        return alarms.count
    }
    func addAlarm(alarm:Alarm){
        alarms.append(alarm)
    }
    func modifyUser(alarm:Alarm, index:Int){
        alarms[index] = alarm
    }
    func removeAlarm(index:Int){
        alarms.remove(at: index)
    }
}
