//
//  CheckTimeGroup.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/16.
//

import Foundation
class CheckTimeGroup:NSObject{
    var checkTimes = [CheckTime]()
    override init() {
        super.init()
    }
    func count()->Int{
        return checkTimes.count
    }
    func addCheckTime(checkTime:CheckTime){
        checkTimes.append(checkTime)
    }
    func modifyCheckTime(checkTime:CheckTime, index:Int){
        checkTimes[index] = checkTime
    }
    func removeCheckTime(index:Int){
        checkTimes.remove(at: index)
    }
}
