//
//  FirstViewController.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/09.
//

import UIKit
//맨 처음 화면, 알람 리스트 View
class FirstViewController: UIViewController {
    @IBOutlet weak var alarmTable: UITableView!
    var alarmGroup = AlarmGroup()
    let center = UNUserNotificationCenter.current() // 노티피케이션 센터
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        alarmTable.dataSource = self
        alarmTable.delegate = self
    }
    //tableView editing 모드 on/off
    @IBAction func editButton(_ sender: UIBarButtonItem) {
        if alarmTable.isEditing == true{
            alarmTable.isEditing = false
            sender.title = "편집"
        }else{
            alarmTable.isEditing = true
            sender.title = "완료"
        }
    }
}
//tableView dataSource
extension FirstViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alarmGroup.count()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell") as! CustomTableViewCell
        let alarm = alarmGroup.alarms[indexPath.row]
        cell.identifier = alarm.identifier
        cell.partLabel.text = alarm.part
        cell.timeLabel.text = alarm.time
        let uiSwitch = UISwitch(frame: CGRect())
        uiSwitch.isOn = true
        uiSwitch.addTarget(self, action: #selector(switchChanged), for: .valueChanged)
        cell.accessoryView = uiSwitch
        return cell
    }
}
//UISwitch를 off하면 알람이 취소되고, on하면 알람이 등록된다.
extension FirstViewController{
    @objc func switchChanged(sender: UISwitch){
        let cell = sender.superview as! UITableViewCell
        let indexPath = alarmTable.indexPath(for: cell)
        let selectedAlarm = alarmGroup.alarms[indexPath!.row]
        //UISwitch off
        if sender.isOn == false{
            selectedAlarm.toggle = false
            //선택한 알람 취소
            center.removePendingNotificationRequests(withIdentifiers: [selectedAlarm.identifier])
        }else{ //UISwitch on
            selectedAlarm.toggle = true
            //선택한 알람 등록
            registerAlarm(identifier: selectedAlarm.identifier)
        }
    }
}
extension FirstViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        //tableViewCell 삭제
        if editingStyle == .delete{
            let selectedAlarm = alarmGroup.alarms[indexPath.row]
            center.removePendingNotificationRequests(withIdentifiers: [selectedAlarm.identifier])
            alarmGroup.removeAlarm(index: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
}
extension FirstViewController{
    func registerAlarm(identifier:String){
        print("알람등록" + identifier)
        
        //현재 시간 구하기(시,분,초)
        let date = Date()
        let calendar = Calendar.current
        let realHour = calendar.component(.hour, from: date)
        let realMinute = calendar.component(.minute, from: date)
        let realSecond = calendar.component(.second, from: date)
        
        //identifier는 사용자에게 입력받은 시간이다.
        let time = identifier.split(separator: ":").map { val -> Int in
            return Int(val)!
        }
        print("현재시간: ",realHour,realMinute,realSecond)
        
        // 현재 시간과 사용자에게 입력받은 시간 차를 계산
        var timeDiffer = Double((time[0] - realHour) * 3600 + (time[1] - realMinute) * 60 + (time[2] - realSecond))
        if timeDiffer < 0{
            timeDiffer = 86400 + timeDiffer
        }
        print("timeDiffer : \(timeDiffer)")
        
        let content = UNMutableNotificationContent() // 노티피케이션 메세지 객체
        content.sound = UNNotificationSound.default
        content.title = NSString.localizedUserNotificationString(forKey: "알람", arguments: nil)
        if time[0] < 12{ //AM
            if time[0] == 0 {
                content.body = NSString.localizedUserNotificationString(forKey: "오전 " + String(format: "%02d", time[0]+12) + ":" + String(format: "%02d", time[1]) + " 입니다", arguments: nil)
            }else{
                content.body = NSString.localizedUserNotificationString(forKey: "오전 " + String(format: "%02d", time[0]) + ":" + String(format: "%02d", time[1]) + " 입니다", arguments: nil)
            }
        }else{ //PM
            if time[0] > 12 {
                content.body = NSString.localizedUserNotificationString(forKey: "오후 " + String(format: "%02d", time[0]-12) + ":" + String(format: "%02d", time[1]) + " 입니다", arguments: nil)
            }else{
                content.body = NSString.localizedUserNotificationString(forKey: "오후 " + String(format: "%02d", time[0]) + ":" + String(format: "%02d", time[1]) + " 입니다", arguments: nil)
            }
        }
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: timeDiffer, repeats: false) //엃마 후에 실행할건지
        let request = UNNotificationRequest(
            identifier: identifier,
            content: content,
            trigger: trigger
        )
        center.delegate = self
        center.add(request) { (error:Error?) in}
        
    }
}
//알람 시간을 선택하는 View(ViewController)와의 데이터 공유를 위해
extension FirstViewController{
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let secondView = segue.destination as? ViewController {
                secondView.delegate = self
            }
    }
}
//extension FirstViewController{
//    func updateTable(){
//        for i in 0..<alarmGroup.count(){
//            let selectedCell = alarmTable.cellForRow(at: [0,i]) as! CustomTableViewCell
//            for j in 0..<selectedCell.subviews.count{
//                if (selectedCell.subviews[j] as? UISwitch) != nil{
//                    let uiSwitch = selectedCell.subviews[j] as! UISwitch
//                    if alarmGroup.alarms[i].toggle == true{
//                        uiSwitch.isOn = true
//                    }else{
//                        uiSwitch.isOn = false
//                    }
//                }
//            }
//        }
//    }
//}

//알람 처리
extension FirstViewController:UNUserNotificationCenterDelegate{
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.badge, .alert, .sound])
        
        //현재 시간 구하기
        let date = Date()
        let calendar = Calendar.current
        let realHour = calendar.component(.hour, from: date)
        let realMinute = calendar.component(.minute, from: date)
        let realHourString = String(format: "%02d", realHour)
        let realMinuteString = String(format: "%02d", realMinute)
        //알람의 이름
        let ident = realHourString+":"+realMinuteString+":00"
        
        //알람이 울리면 해당 시간 알람의 UISwitch는 off로 바꾼다.
        var index = -1
        for i in 0..<alarmGroup.count(){
            let selectedCell = alarmTable.cellForRow(at: [0,i]) as! CustomTableViewCell
            if selectedCell.identifier == ident{
                for j in 0..<selectedCell.subviews.count{
                    if (selectedCell.subviews[j] as? UISwitch) != nil{
                        let uiSwitch = selectedCell.subviews[j] as! UISwitch
                        uiSwitch.isOn = false
                        index = i
                        break
                    }
                }
            }
        }
        alarmGroup.alarms[index].toggle = false
    }
    //Background Notification 처리
//    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
//        withCompletionHandler completionHandler: @escaping () -> Void) {
//        let date = Date()
//        let calendar = Calendar.current
//        let realHour = calendar.component(.hour, from: date)
//        let realMinute = calendar.component(.minute, from: date)
//        let realHourString = String(format: "%02d", realHour)
//        let realMinuteString = String(format: "%02d", realMinute)
//        let ident = realHourString+":"+realMinuteString+":00"
//        var index = -1
//        for i in 0..<alarmGroup.count(){
//            let selectedCell = alarmTable.cellForRow(at: [0,i]) as! CustomTableViewCell
//            if selectedCell.identifier == ident{
//                for j in 0..<selectedCell.subviews.count{
//                    if (selectedCell.subviews[j] as? UISwitch) != nil{
//                        let uiSwitch = selectedCell.subviews[j] as! UISwitch
//                        uiSwitch.isOn = false
//                        index = i
//                        break
//                    }
//                }
//            }
//        }
//        alarmGroup.alarms[index].toggle = false
//     }
}
