//
//  WorldTimeGroup.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/18.
//

import Foundation

class WorldTimeGroup: NSObject{
    var title : String
    var part : String
    var time: String
    init(title:String, part:String, time:String) {
        self.title = title
        self.part = part
        self.time = time
        super.init()
    }
}
