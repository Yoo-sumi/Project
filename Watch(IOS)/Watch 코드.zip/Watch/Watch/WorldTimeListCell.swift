//
//  WorldTimeListCell.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/18.
//


import UIKit

class WorldTimeListCell: UITableViewCell {
    var title: UILabel!
    var part: UILabel!
    var time: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        title = UILabel()
        part = UILabel()
        time = UILabel()
        contentView.addSubview(title)
        contentView.addSubview(part)
        contentView.addSubview(time)
        title.font = UIFont.systemFont(ofSize:25)
        part.font = UIFont.systemFont(ofSize:30)
        time.font = UIFont.systemFont(ofSize:40)
        title.translatesAutoresizingMaskIntoConstraints = false
        part.translatesAutoresizingMaskIntoConstraints = false
        time.translatesAutoresizingMaskIntoConstraints = false
        
        title.leadingAnchor.constraint(equalTo: contentView.leadingAnchor,constant: 20).isActive = true
        title.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        title.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
        //part.trailingAnchor.constraint(equalTo:contentView.trailingAnchor).isActive = true
        part.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        part.leadingAnchor.constraint(equalTo: title.trailingAnchor,constant: 10).isActive = true
        part.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
        time.trailingAnchor.constraint(equalTo:contentView.trailingAnchor,constant: -20).isActive = true
        time.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        time.leadingAnchor.constraint(equalTo: part.trailingAnchor,constant: 10).isActive = true
        time.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
