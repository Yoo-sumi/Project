//
//  ViewController.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/09.
//

import UIKit
//알람 시간 선택하는 View
class ViewController: UIViewController {
    @IBOutlet weak var timePicker: UIDatePicker!
    var delegate: FirstViewController?
    override func viewDidLoad() {
        super.viewDidLoad()
        // 권한 체크
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler: {didAllow, error in
        })
    }
    //이전 View로 돌아가기
    @IBAction func cancelButton(_ sender: UIButton) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    //이전 View로 돌아가기 + 알람 등록하고 알람 리스트(tableViewCell) 추가
    @IBAction func saveButton(_ sender: UIButton) {
        let formatter = DateFormatter() // DateFormatter 클래스 상수 선언
        formatter.dateFormat = "aa HH:mm" // formatter의 dateFormat 속성을 설정
        print("선택시간 : " + formatter.string(from: timePicker.date))
        
        let formatter2 = DateFormatter()
        formatter2.dateFormat = "HH:mm:00"
        //identifier는 알람의 이름(설정한 시간)
        let identifier =  formatter2.string(from: timePicker.date)
        let timeSplit = formatter.string(from: timePicker.date).split(separator: " ").map { val -> String in
            return String(val)
        }
        
        var alarm: Alarm!
        //AM PM 처리
        if timeSplit[0] == "AM"{
            let timeSplit2 = timeSplit[1].split(separator: ":").map { val -> String in
                return String(val)
            }
            if Int(timeSplit2[0])! == 00{
                let t = String(Int(timeSplit2[0])!+12) + ":" + timeSplit2[1]
                alarm = Alarm(identifier: identifier, part: "오전", time: t, toggle: true)
            }else{
                alarm = Alarm(identifier: identifier, part: "오전", time: timeSplit[1], toggle: true)
            }
        }else{
            let timeSplit2 = timeSplit[1].split(separator: ":").map { val -> String in
                return String(val)
            }
            if Int(timeSplit2[0])! > 12 {
                let t = String(Int(timeSplit2[0])!-12) + ":" + timeSplit2[1]
                alarm = Alarm(identifier: identifier, part: "오후", time: t, toggle: true)
            }else{
                alarm = Alarm(identifier: identifier, part: "오후", time: timeSplit[1], toggle: true)
            }
        }
        //알람 추가 + 알람 리스트에 추가
        delegate?.alarmGroup.addAlarm(alarm: alarm)

        let indexPath = IndexPath(row: (delegate?.alarmGroup.count())!-1, section: 0)
        delegate?.alarmTable.insertRows(at: [indexPath], with: .automatic)
        delegate?.registerAlarm(identifier: identifier)

        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
