//
//  SearchWorldTimeViewController.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/16.
//

import UIKit
//세계 시간 리스트에 추가할 수 있는 View
class SearchWorldTimeViewController: UIViewController {
    
    var delegate: WorldTimeViewController?
    @IBOutlet weak var searchBar: UISearchBar!
    var pair = [String:String]()
    var worldTimes = [WorldTime]()
    var nameArray = [String]()
    var filteredWorldTimes: [String]!
    @IBOutlet weak var worldTimeTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //438개 나라의 시간을 가져온다.
        for tz in TimeZone.knownTimeZoneIdentifiers {
            let timeZone = TimeZone(identifier: tz)
            var translatedName : String = timeZone?.localizedName(for: NSTimeZone.NameStyle.shortGeneric, locale: Locale(identifier: "ko_KR")) ?? ""
            let date = DateFormatter()
            date.locale = Locale(identifier: "ko_KR")
            date.timeZone = timeZone
            date.dateFormat = "HH:mm"
            var name =  translatedName.components(separatedBy: " 시간")
            if name[0] == "Montreal"{
                name[0] = "몬트리올"
            }
            if name[0] == "고드호프"{
                continue
            }
            nameArray.append(name[0]) //나라 이름 array
            var time = date.string(from: Date())
            var worldTime = WorldTime(name: name[0], time: time)
            worldTimes.append(worldTime) //나라 이름과 그 나라의 현재 시간 array
            pair[name[0]] = time //나라 이름과 그 나라의 현재 시간 dictionary
        }
        //오름차순 정렬
        worldTimes.sort(by: {$0.name < $1.name})
        nameArray.sort(by: {$0 < $1})
        //searchBar를 위한 필터링된 array
        filteredWorldTimes = nameArray
       
        
        worldTimeTableView.dataSource = self
        worldTimeTableView.delegate = self
        searchBar.delegate = self
        
    }
    //이전 View(WorldTimerViewController)로 돌아가기
    @IBAction func cancelButton(_ sender: UIButton) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
//나라의 이름 리스트
extension SearchWorldTimeViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredWorldTimes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WorldTimeTableViewCell") as! WorldTimeTableViewCell
        cell.title.text = filteredWorldTimes[indexPath.row]
        return cell
    }

}
//searchBar에 입력된 글자와 일치하는 나라의 이름만 보여지도록 필터링
extension SearchWorldTimeViewController:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredWorldTimes = searchBar.text!.isEmpty ? nameArray : nameArray.filter({(dataString:String)->Bool in
            return dataString.range(of: searchBar.text!,options: .caseInsensitive) != nil
        })
        worldTimeTableView.reloadData()
    }
}
//나라가 선택되면 이전 View(WorldTimeViewController)에 tableViewCell로 추가
extension SearchWorldTimeViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCell = worldTimeTableView.cellForRow(at: indexPath) as! WorldTimeTableViewCell

        var time =  pair[selectedCell.title.text!]!.components(separatedBy: ":")
        var full_time:String!
        var part :String!
        
        //AM PM 처리
        if Int(time[0])! > 11 {
            part = "오후"
            if Int(time[0])! > 12 {
                full_time =  "0" + String(Int(time[0])!-12) + ":" + time[1]
            }else{
                full_time = time[0] + ":" + time[1]
            }
        }else{
            part = "오전"
            if time[0] == "00"{
                full_time = String(Int(time[0])!+12) + ":" + time[1]
            }else{
                full_time = time[0] + ":" + time[1]
            }
        }
        
        //tableViewCell로 추가
        let worldTimeGroup = WorldTimeGroup(title: selectedCell.title.text!, part: part, time: full_time)
        let indexPath = IndexPath(item: (delegate?.worldTimeList.count)!, section: 0)
        delegate?.worldTimeList.append(worldTimeGroup)
        delegate?.worldTimeTableView.insertRows(at: [indexPath], with: .automatic)
        
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
