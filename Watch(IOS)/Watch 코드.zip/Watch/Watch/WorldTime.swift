//
//  WorldTime.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/16.
//

import Foundation

class WorldTime: NSObject{
    var name : String
    var time : String
    init(name:String, time:String) {
        self.name = name
        self.time = time
        super.init()
    }
}
