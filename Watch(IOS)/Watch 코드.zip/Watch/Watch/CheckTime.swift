//
//  CheckTime.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/16.
//

import Foundation
class CheckTime: NSObject{
    var title : String
    var time: String
    init(title:String, time:String){
        self.title = title
        self.time = time
        super.init()
    }
}
