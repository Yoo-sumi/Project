//
//  TableViewCell.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/10.
//

import UIKit

class WorldTimeTableViewCell: UITableViewCell {
    var title: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        title = UILabel()
        contentView.addSubview(title)
        title.font = UIFont.systemFont(ofSize:15)
        title.translatesAutoresizingMaskIntoConstraints = false
       
        title.leadingAnchor.constraint(equalTo: contentView.leadingAnchor,constant: 30).isActive = true
        title.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        title.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}

