//
//  Alarm.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/09.
//

import Foundation

class Alarm: NSObject{
    var identifier : String
    var part : String
    var time: String
    var toggle: Bool
    init(identifier:String, part:String, time:String, toggle: Bool) {
        self.identifier = identifier
        self.part = part
        self.time = time
        self.toggle = toggle
        super.init()
    }
}
