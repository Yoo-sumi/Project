//
//  TableViewCell.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/10.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    var partLabel: UILabel!
    var timeLabel: UILabel!
    var identifier: String!
    override func awakeFromNib() {
        super.awakeFromNib()
        partLabel = UILabel()
        timeLabel = UILabel()
        contentView.addSubview(partLabel)
        contentView.addSubview(timeLabel)
        partLabel.font = UIFont.systemFont(ofSize:30)
        timeLabel.font = UIFont.systemFont(ofSize:30)
        partLabel.translatesAutoresizingMaskIntoConstraints = false
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        partLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor,constant: 30).isActive = true
        partLabel.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        partLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
        timeLabel.trailingAnchor.constraint(equalTo:contentView.trailingAnchor).isActive = true
        timeLabel.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        timeLabel.leadingAnchor.constraint(equalTo: partLabel.trailingAnchor,constant: 10).isActive = true
        timeLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
