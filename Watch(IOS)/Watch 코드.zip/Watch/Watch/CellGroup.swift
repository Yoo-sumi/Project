//
//  Cell.swift
//  project
//
//  Created by yoosumi on 2021/05/11.
//

import Foundation

class CellGroup: NSObject{
    var identifier : String
    var cell : CustomTableViewCell
    init(identifier:String, cell : CustomTableViewCell) {
        self.identifier = identifier
        self.cell = cell
        super.init()
    }
}
