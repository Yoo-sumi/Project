//
//  TestViewController.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/09.
//

import UIKit

//스톱워치 View
class StopWatchViewController: UIViewController {
    var mainTimer:Timer?
    var checkTimeListCount = 0
    var checkTimes = [String]()
    var timeCount = 0
    
    @IBOutlet weak var checkTimeList: UITableView!
    @IBOutlet weak var frontTime: UILabel!
    @IBOutlet weak var behindTime: UILabel!
    @IBOutlet weak var btn_init: UIButton!
    @IBOutlet weak var btn_start: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btn_init.isEnabled = false
        checkTimeList.dataSource = self
    }
    //시간 초기화(0초로) + 시간 기록(랩)
    @IBAction func initButton(_ sender: UIButton) {
        //시간 기록
        if sender.currentTitle == "랩"{
            checkTimeListCount += 1
            let str = String(frontTime.text!)+String(behindTime.text!)
            checkTimes.append(str)
            let indexPath = IndexPath(item: checkTimeListCount-1, section: 0)
            checkTimeList.insertRows(at: [indexPath], with: .automatic)
            print(str)
        }else{ //시간 초기화(0초로)
            btn_init.isEnabled = false
            btn_init.setTitle("랩", for: .normal)
            resetAction()
            checkTimeListCount = 0
            checkTimes = [String]()
            checkTimeList.reloadData()
        }
    }
    //스톱워치 시작 or 중단
    @IBAction func startButton(_ sender: UIButton) {
        if sender.currentTitle == "시작"{
            sender.setTitle("중단", for: .normal)
            btn_init.isEnabled = true
            btn_init.setTitle("랩", for: .normal)
            startAction()
        }else{
            sender.setTitle("시작",for: .normal)
            btn_init.setTitle("재설정", for: .normal)
            stopAction()
        }
    }
}

extension StopWatchViewController{
    //스톱워치 시작
    func startAction() {
        guard mainTimer == nil else { return }
        mainTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: {
            (_) in self.timeCount += 1
            DispatchQueue.main.async {
                let timeString = self.makeTimeLabel(count: self.timeCount)
                self.frontTime.text = timeString.0
                self.behindTime.text = ".\(timeString.1)" } }) }
    func makeTimeLabel(count:Int) -> (String,String) { //return - (TimeLabel, decimalLabel)
        let decimalSec = count % 10
        let sec = (count / 10) % 60
        let min = (count / 10) / 60
        let sec_string = "\(sec)".count == 1 ? "0\(sec)" : "\(sec)"
        let min_string = "\(min)".count == 1 ? "0\(min)" : "\(min)"
        return ("\(min_string):\(sec_string)","\(decimalSec)")
    }
    //스톱워치 중단
    func stopAction() {
        mainTimer?.invalidate()
        mainTimer = nil
    }
    //스톱워치 시간 리셋(0초로)
    func resetAction() {
        mainTimer?.invalidate()
        mainTimer = nil
        timeCount = 0
        frontTime.text = "00:00"
        behindTime.text = ".0"
    }
}
//시간 기록 tableView
extension StopWatchViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checkTimeListCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StopWatchTableViewCell") as! StopWatchCustomTableViewCell
        cell.title.text = "랩 "+String(indexPath.row+1)
        cell.time.text = checkTimes[indexPath.row]
        return cell
    }
}
