//
//  WorldTimeViewController.swift
//  project_copy
//
//  Created by yoosumi on 2021/05/16.
//

import UIKit
//세계 시간 리스트 View
class WorldTimeViewController: UIViewController {
    var worldTimeList = [WorldTimeGroup]()
    var pair = [String:String]()
    @IBOutlet weak var editButton: UIBarButtonItem!
    let interval = 1.0
    
    @IBOutlet weak var worldTimeTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        worldTimeTableView.dataSource = self
        worldTimeTableView.delegate = self
        
        //현재 시간
        let date = Date()
        let calendar = Calendar.current
        let realHour = calendar.component(.hour, from: date)
        let realMinute = calendar.component(.minute, from: date)
        let realSecond = calendar.component(.second, from: date)
        let addStr = String(realHour) + ":" + String(realMinute)
        var time =  addStr.components(separatedBy: ":")
        
        //AM PM 처리
        var full_time:String!
        var part :String!
        
        if Int(time[0])! > 11 {
            part = "오후"
            if Int(time[0])! > 12 {
                full_time =  String(format: "%02d",Int(time[0])!-12) + ":" + time[1]
            }else{
                full_time = String(format: "%02d",Int(time[0])!) + ":" + time[1]
            }
        }else{
            part = "오전"
            if time[0] == "00"{
                full_time = String(format: "%02d",Int(time[0])!+12) + ":" + time[1]
            }else{
                full_time = String(format: "%02d",Int(time[0])!) + ":" + time[1]
            }
        }
        
        //기본적으로 대한민국의 시간은 추가되어있게함.
        let worldTimeGroup = WorldTimeGroup(title: "대한민국", part: part, time: full_time)
        let indexPath = IndexPath(item: worldTimeList.count, section: 0)
        worldTimeList.append(worldTimeGroup)
        worldTimeTableView.insertRows(at: [indexPath], with: .automatic)
        
        //1초마다 시간 업데이트
        Timer.scheduledTimer(timeInterval: interval, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        
    }
    //시간 업데이트
    @objc func updateCounter(){
        getWorldTime() //현재 시간 가져오기
        
        for i in 0..<worldTimeList.count{
            var full_time:String!
            var part :String!
            let indexPath = IndexPath(item: i, section: 0)
            let worldTimeListCell = worldTimeTableView.cellForRow(at: indexPath) as! WorldTimeListCell
            
            //해당 나라의 시간 가져오기
            var time =  pair[worldTimeList[i].title]!.components(separatedBy: ":")
            
            //AM PM 처리
            if Int(time[0])! > 11 {
                part = "오후"
                if Int(time[0])! > 12 {
                    full_time =  String(format: "%02d", Int(time[0])!-12) + ":" + time[1]
                }else{
                    full_time = String(format: "%02d", Int(time[0])!) + ":" + time[1]
                }
            }else{
                part = "오전"
                if time[0] == "00"{
                    full_time = String(format: "%02d", Int(time[0])!+12) + ":" + time[1]
                }else{
                    full_time = String(format: "%02d", Int(time[0])!) + ":" + time[1]
                }
            }
            
            //시간 업데이트
            worldTimeListCell.time.text = full_time
            worldTimeListCell.part.text = part
        }
    }
    //tableView editing mode on/off
    @IBAction func editClick(_ sender: UIBarButtonItem) {
        if editButton.title == "편집"{
            editButton.title = "완료"
            worldTimeTableView.isEditing = true
        }else{
            editButton.title = "편집"
            worldTimeTableView.isEditing = false
        }
    }
    
}
//SearchWorldTimeViewController과의 데이터 공유를 위해
extension WorldTimeViewController{
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let searchWorldTimeViewController = segue.destination as? SearchWorldTimeViewController {
                searchWorldTimeViewController.delegate = self
            }
    }
}
//세계 시간 리스트
extension WorldTimeViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return worldTimeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WorldTimeListCell") as! WorldTimeListCell
        cell.title.text = worldTimeList[indexPath.row].title
        cell.part.text = worldTimeList[indexPath.row].part
        cell.time.text = worldTimeList[indexPath.row].time
        return cell
    }

}
//세계 시간 tableViewCell 삭제
extension WorldTimeViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            worldTimeList.remove(at: indexPath.row)
            worldTimeTableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
}
//현재 시간 가져오기
extension WorldTimeViewController{
    func getWorldTime(){
        for tz in TimeZone.knownTimeZoneIdentifiers {
            let timeZone = TimeZone(identifier: tz)
            var translatedName : String = timeZone?.localizedName(for: NSTimeZone.NameStyle.shortGeneric, locale: Locale(identifier: "ko_KR")) ?? ""
            let date = DateFormatter()
            date.locale = Locale(identifier: "ko_KR")
            date.timeZone = timeZone
            date.dateFormat = "HH:mm"
            var name =  translatedName.components(separatedBy: " 시간")
            if name[0] == "Montreal"{
                name[0] = "몬트리올"
            }
            var time = date.string(from: Date())
            var worldTime = WorldTime(name: name[0], time: time)
            pair[name[0]] = time
        }
    }
}
