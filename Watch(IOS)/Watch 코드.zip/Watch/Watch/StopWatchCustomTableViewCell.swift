//
//  TableViewCell.swift
//  localNotification
//
//  Created by yoosumi on 2021/05/10.
//

import UIKit

class StopWatchCustomTableViewCell: UITableViewCell {
    var title: UILabel!
    var time: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        title = UILabel()
        contentView.addSubview(title)
        title.font = UIFont.systemFont(ofSize:20)
        title.translatesAutoresizingMaskIntoConstraints = false
        
        time = UILabel()
        contentView.addSubview(time)
        time.font = UIFont.systemFont(ofSize:20)
        time.translatesAutoresizingMaskIntoConstraints = false
        
        title.leadingAnchor.constraint(equalTo: contentView.leadingAnchor,constant: 30).isActive = true
        title.trailingAnchor.constraint(equalTo: time.leadingAnchor).isActive = true
        title.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        title.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
        time.trailingAnchor.constraint(equalTo: contentView.trailingAnchor,constant: -20).isActive = true
        time.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        time.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
